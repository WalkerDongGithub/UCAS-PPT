This directory contains miscellaneous files that don't necessarily fit
into any of the examples but can be useful.

* tinyalu.sv---This file provides the TinyALU as a SystemVerilog file.
You use it by replacing the `vcom` line in the `run.do` file with
another `vlog` line that compiles this file.


